pioneer3dx_description
======================

A ROS/Gazebo Pioneer 3DX model based on the Gazebo provided model.

To install:
```
$ cd <catking_workspace_directory>/src
$ git clone URL # (see github)
$ cd ..
$ catkin_make
```
